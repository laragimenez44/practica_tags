# Versión 1.1 Agregar mas de un teléfono
# crear contacto 
# buscar contacto
# eliminar contacto
# modificar contacto
# imprimir agenda

#agregar/crear contacto
def agregar_contacto(agenda:dict ,nombre:str,numero:int)->None:
    agenda[nombre] = [numero]
    
def agregar_telefono(agenda:dict,nombre:str,numero_nuevo:int):
    if nombre in agenda:
        lista_de_telefonos = agenda[nombre]
        lista_de_telefonos.append(numero_nuevo)
        agenda[nombre] = lista_de_telefonos

def buscar_contacto(agenda:dict,nombre:str)->int:
    if nombre in agenda:
        devolver = agenda[nombre]
    else:
        devolver = -1
    return devolver

def modificar_contacto(agenda:dict,nombre:str, numero_nuevo:int)->None:
    agenda[nombre] = numero_nuevo

def eliminar_contacto(agenda:dict,nombre:str)->None:
    if nombre in agenda:
        del (agenda[nombre])
        devolver = 1
    else:
        devolver = -1
    return devolver
def imprimir_contactos(agenda:dict)->None:
    for contacto in agenda:
        print (contacto)

def imprimir_numeros(agenda:dict)->None:
    for nombre in agenda:
        print(agenda[nombre])

def imprimir_contactos_numeros(agenda:dict)->None:
    for nombre in agenda:
        print(nombre,":", agenda[nombre])

def menu():
    opcion = 0
    while opcion < 1 or opcion > 6:
        print("--")
        print("(1) Añadir contacto")
        print("(2) Buscar contacto")
        print("(3) Eliminar")
        print("(4) Imprimir agenda")
        print("(5) Agregar telefono a contacto")
        print("(6) Salir del programa")
        print("--")
        opcion = int(input("Elija una opcion: "))
        print("--")
    return opcion

agenda = {}
opcion = 0
while opcion != 6:
    opcion = menu()
    if opcion == 1:
        nombre = input("Nombre: ")
        telefono = input("telefono: ")
        agregar_contacto(agenda,nombre,telefono)
        print("Contacto Agregado")
    if opcion == 2:
        nombre = input("Nombre: ")
        respuesta = buscar_contacto(agenda,nombre)
        if respuesta != -1:
            print (f"El teléfono de {nombre} es: {respuesta}")
        else:
            print (f"{nombre} no se encuentra en la agenda.")
    if opcion == 3:
        nombre = input("Nombre: ")
        respuesta = eliminar_contacto(agenda,nombre)
        if respuesta != -1:
            print (f"{nombre} ha sido eliminado de la agenda")
        else:
            print (f"{nombre} no se encuentra en la agenda.")
    if opcion == 4:
        imprimir_contactos_numeros(agenda)
    if opcion == 5:
        nombre = input("Nombre: ")
        telefono = input("telefono: ")
        agregar_telefono(agenda,nombre,telefono)

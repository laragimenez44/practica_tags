# Proyecto final integrador Programacion 1

Desarrollar en grupos de a 3 un sistema de altas, bajas y modificaciones para un problema en particular.
Se entrega como ejemplo un ABM de contactos para una agenda.

## Modalidad:

Evaluacion
Grupal e Individualmente:

Grupal: 3 entregas
1) Semana 1: 31/10 Resumen de proyecto
Documento con:
+ descripcion del proyecto
+ funcionalidades

2) Semana 3: 10/11 Entrega preliminar:
+ archivo zip con lo que se tenga hasta el momento
+ Documento contanbdo que se tiene y que falta implementar (estado de situacion del proyecto)
- que anda
- que no anda
- que falta implementar

3) Semana 4: 17/11 Entrega final
- Codigo fuente
- README.md #informe

4) Semana 5: Defensa

Individual, 
+ cada une hace un reporte de avance semanal
+ defensa

Debe incluir:
1) posibilidad de cargar, modificar y eliminar
2) grabar los datos en un archivo
3) leer los datos de un archivo
4) imprimir (mostrar en pantalla)
5) Un menu de usuario para ejecutar las diferentes acciones

Condiciones
+ no deberia encontrarse errores graves (por error grave se entiende por errores que detengan el funcionamiento del programa
+ Las funciones deben tener definidos los tipos de entrada y de salida
+ Testear con asserts las funciones suma puntos


